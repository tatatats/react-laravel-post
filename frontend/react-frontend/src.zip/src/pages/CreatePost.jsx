import PostForm from '../components/PostForm';

const CreatePost = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>新規投稿</h1>
      <PostForm />
    </div>
  );
};

export default CreatePost;