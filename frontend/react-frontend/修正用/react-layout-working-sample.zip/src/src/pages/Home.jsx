import './Home.css';

const Home = () => {
  return (
    <div className="home-container">
      <div className="main-content">
        <h1>投稿一覧</h1>
        <ul className="post-list">
          <li>テスト投稿</li>
        </ul>
      </div>
    </div>
  );
};

export default Home;
